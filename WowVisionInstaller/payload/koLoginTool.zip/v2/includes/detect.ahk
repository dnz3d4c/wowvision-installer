﻿; Which game version is actually running - read from the CLIENT'S OWN FILES,
; not from the screen.
;
; The order is the whole point. Screen recognition cannot tell you which screen
; you are on until it already knows the game version: IsLoginScreen,
; IsCharSelectionScreen, IsCharCreationScreen and the one-button-popup probe all
; branch on it in the helper, and 10 of the 49 widget coordinates differ between
; Era and TBC. Deriving the version from pixels would close that loop on itself,
; and it would close it LATE - the login screen, the one a mismatched tool gets
; stranded on, is where the two clients look most alike.
;
; The client says it plainly instead. Next to every WowClassic.exe sits a
; .flavor.info ("wow_classic_era", "wow_anniversary", "wow_classic"), and the
; shared .build.info one level up carries the version per product. Both are
; plain text; reading the pair costs 0.65 ms measured. So: find the window, ask
; Windows for its process path, read two files, and hand the recognition a
; version it can trust before the first frame is ever captured.
;
; The VERSION decides, not the flavor name. "wow_anniversary" is TBC today and
; will be Wrath after the next rollover - keying on the flavor would silently
; keep loading TBC coordinates through that change, which is exactly the failure
; this is meant to end.

global gGametypePin := false      ; user picked one by hand -> never override it
global gDetectedPid := 0          ; client the current detection came from
global gDetectedGametype := ""    ; what that client reported ("" = unsupported)
global gDetectedClientDir := ""   ; the client's flavor folder (…\_anniversary_)
; When the current client's window turned up, and whether the tool was already
; running when it did. A client we WATCHED appear is a client that is starting,
; and that is the one unrecognized screen the tool can put a name to - see the
; loading announcement in CheckMode. A client that was already there when the
; tool came up says nothing about its own age, so it gets no such claim.
global gClientSeenTick := 0
global gClientWitnessed := false
global gLoadingAnnounced := false ; "the game is starting" is said once per client

; The first component of the client version maps onto the data.ini sections.
; Versions the tool has no section for return "" - that has to be SAID, never
; quietly rounded to the nearest section.
GametypeFromVersion(version, flavor := "") {
    ; Forever first: its flavor pins it regardless of the build, and its
    ; build (1.60+) would otherwise be mistaken for Era.
    if IsForeverFlavor(flavor)
        return "Forever"
    parts := StrSplit(version, ".")
    major := Integer(parts[1])
    minor := parts.Length >= 2 ? Integer(parts[2]) : 0
    if (major = 1 && minor >= 60)
        return "Forever"
    switch major {
        case 1: return "Classic"
        case 2: return "BurningCrusade"
        case 4: return "Cata"
    }
    if (major >= 9)
        return "Retail"
    return ""                      ; 3 = Wrath, 5 = Mists: no data.ini section
}

; Second line of a .flavor.info ("Product Flavor!STRING:0" is the header).
ReadFlavor(dir) {
    try {
        for line in StrSplit(FileRead(dir "\.flavor.info", "UTF-8"), "`n", "`r") {
            t := Trim(line)
            if (t = "" || InStr(t, "!"))
                continue
            return t
        }
    }
    return ""
}

; .build.info is pipe-delimited with a TYPED header ("Version!STRING:0"), one
; row per installed product. Find the columns by name rather than by index - the
; column order is Blizzard's to change, and picking the wrong one would hand us
; a confident, wrong version.
ReadBuildVersion(root, flavor) {
    try text := FileRead(root "\.build.info", "UTF-8")
    catch
        return ""
    lines := StrSplit(text, "`n", "`r")
    if (lines.Length < 2)
        return ""
    head := StrSplit(lines[1], "|")
    verCol := 0, prodCol := 0
    for i, h in head {
        name := StrSplit(Trim(h), "!")[1]
        if (name = "Version")
            verCol := i
        else if (name = "Product")
            prodCol := i
    }
    if (!verCol || !prodCol)
        return ""
    loop lines.Length - 1 {
        cols := StrSplit(lines[A_Index + 1], "|")
        if (cols.Length < Max(verCol, prodCol))
            continue
        if (Trim(cols[prodCol]) = flavor)
            return Trim(cols[verCol])
    }
    return ""
}

; What the running client is. Returns "" when there is nothing to look at yet -
; the tool routinely starts before the game, so "not known" is a normal state,
; not an error.
DetectGameVersion() {
    title := WowWinTitle()
    if (title = "")
        return ""
    try {
        pid := WinGetPID(title)
        exe := WinGetProcessPath(title)
    } catch {
        return ""
    }
    if (exe = "")
        return ""
    SplitPath(exe, , &dir)
    SplitPath(dir, , &root)
    flavor := ReadFlavor(dir)
    version := ReadBuildVersion(root, flavor)
    gametype := (version != "") ? GametypeFromVersion(version, flavor) : ""
    ; Fallback for an install whose .build.info we could not read: Era and
    ; Forever are the flavors whose name pins the version on its own.
    if (gametype = "" && version = "" && flavor = "wow_classic_era")
        gametype := "Classic"
    if (gametype = "" && version = "" && IsForeverFlavor(flavor))
        gametype := "Forever"
    return {pid: pid, exe: exe, flavor: flavor, version: version, gametype: gametype}
}

; Adopt what the client reports. Cheap enough to call from the 1 Hz watcher: it
; keys on the client's PID and does nothing at all until that changes.
;
; Never mid-flow - swapping widget coordinates underneath a running click chain
; is how a delete confirmation ends up somewhere it should not be. Deferring is
; safe because gDetectedPid is only advanced once we actually act on it.
ApplyDetectedGametype() {
    global gGametypePin, gHasSetupGametype, gDetectedPid, gDetectedGametype, gBusy
    if gBusy
        return
    if gGametypePin {
        ; A pinned game type is never replaced, but the tool still has to know
        ; WHICH client runs: the Forever speech history is asked for by pid and
        ; the speech folder sits in the client's folder. The first-start setup
        ; always pins, so without this the history was never asked for and
        ; every hover counted as a silent repeat.
        info := DetectGameVersion()
        if (info = "" || info.pid = gDetectedPid)
            return
        gDetectedPid := info.pid
        SplitPath(info.exe, , &clientDir)
        global gDetectedClientDir := clientDir
        Log("Detect: pid " info.pid " [" info.exe "] - game type pinned to " gHasSetupGametype)
        return
    }
    info := DetectGameVersion()
    if (info = "" || info.pid = gDetectedPid)
        return
    gDetectedPid := info.pid
    gDetectedGametype := info.gametype
    SplitPath(info.exe, , &clientDir)
    global gDetectedClientDir := clientDir
    global gClientSeenTick := A_TickCount
    ; gLogStart is set when Main() starts, so "the tool had already been up for
    ; five seconds when this client appeared" means we saw it launch.
    global gClientWitnessed := (A_TickCount - gLogStart > 5000)
    global gLoadingAnnounced := false
    Log("Detect: pid " info.pid " flavor='" info.flavor "' version='" info.version "'"
        . " -> " (info.gametype = "" ? "UNSUPPORTED" : info.gametype) " [" info.exe "]")
    if (info.gametype = "") {
        ; Identified, but we have no table for it. Say so - the alternative is
        ; running on the nearest section and misclicking for an hour.
        Say(T("This game version is not supported yet.") " " info.version)
        return
    }
    if (info.gametype != gHasSetupGametype) {
        Log("Detect: switching game type " gHasSetupGametype " -> " info.gametype)
        gHasSetupGametype := info.gametype
        LoadGameData()
        ; The create-character menu bakes race/class INDICES into its entries
        ; (CreateCharClosure), and those index the tables LoadGameData just
        ; replaced. Era's "undead" is race 6; on BC the Draenei sit at 5, so 6
        ; is the orc - the tool created two orcs for an undead that way
        ; (2026-11-02). Rebuild the menu from the new tables, as the hand-pick
        ; path (GametypeSelectAction) always did, and put the cursor on the new
        ; root: the old nodes are orphans now.
        BuildMainMenu()
        global gCurrentItem := gMainMenu
        ; The helper loads the same data.ini section and is handed --gametype at
        ; spawn, so it has to be restarted or it keeps classifying screens with
        ; the old client's rules.
        SenseStop()
        Say(T("game version detected") ": " T(info.gametype))
    }
    ; The client is up and its version is settled, so the helper can be started
    ; HERE instead of when the first probe wants an answer. That is a process
    ; start, a pipe pair and the OCR engine - about half a second, and it used
    ; to sit squarely between "the game is on screen" and the tool saying
    ; anything about it. Starting it now overlaps it with the client's own
    ; start-up, which is time nobody is using anyway.
    ; (SenseStart calls back into this function; that call returns immediately
    ; because gDetectedPid has already been advanced above.)
    SenseStart()
}

; Every screen check on Era/BC keys on the exact colours of the recolored
; textures the installer copies into the client's Interface folder. When they
; are missing, EVERY glue screen classifies "unknown" - a state the generic
; "close the dialog, Alt F1 twice" hint cannot get anyone out of. One file
; stands in for the whole set: BUTTONS\128RedButton.BLP is the GenericRedButton
; fiducial that login, charselect and every popup row probe for.
;
; Only answerable once a client has been detected (the check needs ITS
; Interface folder, not a guess); before that it reports "not missing" so the
; caller falls back to the generic hint.
FiducialTexturesMissing() {
    global gDetectedClientDir
    if (gDetectedClientDir = "")
        return false
    return !FileExist(gDetectedClientDir "\Interface\BUTTONS\128RedButton.BLP")
}

; The one announcement for "the tool cannot name this screen", shared by the
; CheckMode streak watcher and InitLogin. Forks on the texture self-check:
; missing textures are an install problem with a known repair, and telling the
; user to close a dialog would send them chasing a dialog that does not exist.
SayUnknownScreenHint() {
    if (gHasSetupGametype = "Forever") {
        ; No textures to repair on Forever: the screen is simply not mapped
        ; yet. The client narrates it anyway; the capture is for the mapping.
        Say(T("Forever mode: the game reads the screen itself. Press Control Alt F3 to save a screenshot for calibration."))
        return
    }
    if FiducialTexturesMissing() {
        Log("unknown screen and Interface\BUTTONS\128RedButton.BLP is missing - announcing the texture repair")
        Say(T("The screen recognition textures are missing from the game folder. Please run the Sku installer to reinstall the login tool."))
    } else {
        Say(T("Unknown screen. Close the dialog in the game, then press Alt F1 twice."))
    }
}
