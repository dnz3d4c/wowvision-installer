local L = LibStub("AceLocale-3.0"):NewLocale("WowVision", "koKR")
if not L then return end

L["Mists"] = "판다리아의 안개"

L["Miscellaneous"] = "기타"
L["Cursor"] = "커서"
L["Tooltip"] = "툴팁"
L["Quality"] = "등급"

-- Tooltip, Compare: Pawn's upgrade summary and the comparison with the equipped item
L["Compare"] = "비교"
L["Pawn Summary"] = "Pawn 요약"
L["Compare With Equipped Item"] = "장착 아이템과 비교"
L["Game"] = "게임"
L["Pawn: %s, %s"] = "Pawn: %s, %s"
L["upgrade of %d percent"] = "%d퍼센트 향상"
L["big upgrade"] = "대폭 향상"
L["over %s"] = "%s 대비"
L["Compared to equipped: %s"] = "장착 아이템과 비교: %s"
L["Slot %d of %d:"] = "칸 %d of %d:"
L["Nothing equipped in this slot"] = "이 칸에 장착한 아이템 없음"
L["unknown item"] = "알 수 없는 아이템"
L["Also takes off the off hand: %s"] = "보조장비도 해제: %s"
L["Item level"] = "아이템 레벨"
L["same"] = "같음"
L["%s more"] = "%s 높음"
L["%s less"] = "%s 낮음"
L["%s: %s"] = "%s: %s"
L["No difference in stats"] = "능력치 차이 없음"
