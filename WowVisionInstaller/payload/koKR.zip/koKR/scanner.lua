local L = LibStub("AceLocale-3.0"):NewLocale("WowVision", "koKR")
if not L then return end

-- Scanner (tree of things and where they are)
L["Scanner"] = "스캐너"
L["Scan Radius"] = "스캔 반경"
L["Entries Per Category"] = "범주별 항목 수"
L["Scanner as Tree"] = "스캐너를 트리로 표시"
L["Refresh"] = "새로고침"
L["Refreshed"] = "새로고침 완료"
L["Error"] = "오류"
L["Player"] = "플레이어"
L["Corpse"] = "시체"
L["Graveyards"] = "무덤"
L["Navigate to Nearest"] = "가장 가까운 항목으로 길 안내"
L["Nothing to navigate to"] = "길 안내할 대상 없음"
